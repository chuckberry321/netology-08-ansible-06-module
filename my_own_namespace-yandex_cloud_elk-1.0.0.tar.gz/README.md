# Ansible Collection - my_own_namespace.yandex_cloud_elk

Documentation for the collection.

Коллекция содержит роль my_module.
Роль вызвает модуль my_own_module.
Модуль осуществляет проверку наличия файла по пути path и запись текста content в этот файл, если он не существует.

